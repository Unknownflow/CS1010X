from runes import *

def runeception(function, size):
    result = function
    
    for i in range(2, size):
        n = i * i
        
        j = n - 2 # j denotes the side vertical length not inclusive of top and bottom
        k = n - 1 # k denotes max length - 1
        # rotate left to make one col of n patterns horizontal
        n_horizontal = quarter_turn_left(stackn(n, function))
        # rotate left to make one col of n - 2 patterns horizontal
        j_horizontal = quarter_turn_left(stackn(j, quarter_turn_right(function)))

        
        center = quarter_turn_left(stack_frac(
            1/n,
            j_horizontal,
            stack_frac(
                j/k,
                result,
                j_horizontal,
                )
            ))
        

        result = quarter_turn_right(stack_frac(
            1/n,
            n_horizontal,
            stack_frac(
                j/k,
                center,
                n_horizontal,
                )
            ))

    return result



show(runeception(make_cross(rcross_bb), 25))
